# Source code

Place your actual Python source files in this folder.

Suggested modules (only create these if they match your implementation):
- `camera.py` — camera capture
- `recognition.py` — face detection/recognition
- `lock_control.py` — hardware driver interface
- `notifications.py` — owner notification

Do not connect a physical lock until the software has been tested safely with the lock disconnected. Keep credentials and biometric data out of the repository.
