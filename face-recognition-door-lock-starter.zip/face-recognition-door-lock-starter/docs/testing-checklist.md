# Testing checklist

- [ ] Confirm camera works.
- [ ] Test face detection without connecting a lock.
- [ ] Test authorized-face matching with consented test data.
- [ ] Test unknown-face handling.
- [ ] Confirm no lock action occurs on camera or network failure.
- [ ] Test notification behavior without exposing credentials.
- [ ] Verify manual override and safe exit behavior.
- [ ] Review privacy and data-retention practices.
- [ ] Record actual hardware models, software versions, and test results.
