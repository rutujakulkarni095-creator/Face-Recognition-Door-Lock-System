# Face Recognition Door Lock System

A starter repository for a B.Tech E&TC project that explores face-based access control.

## Project overview
The proposed system is designed to:
- Detect a face using a camera.
- Compare the detected face with an enrolled/authorized face.
- Grant access only when the face is recognized.
- Record or notify the owner about an unrecognized access attempt.

> **Important:** This repository is a documentation and implementation starter, not a finished or tested door-lock controller. Hardware wiring, face-recognition logic, email alerts, and safety checks must be implemented and tested for your actual setup before connecting a physical lock.

## Current status
- [x] Project overview and repository structure
- [ ] Add your actual source code
- [ ] Add hardware details and wiring diagram
- [ ] Implement and test face recognition
- [ ] Implement owner notification
- [ ] Test fail-safe behavior with the lock disconnected

## Suggested hardware
Update this list to match the components you actually used:
- Raspberry Pi (model: __________)
- Camera module / USB webcam
- Relay or suitable driver circuit
- Electronic lock / solenoid (with appropriate power supply)
- Jumper wires and enclosure

## Suggested software
Update this list to match your implementation:
- Python
- OpenCV or another face-processing library
- GPIO library compatible with your Raspberry Pi
- Email/notification service (if used)

## Repository structure
```text
face-recognition-door-lock/
├── README.md
├── requirements.txt
├── .gitignore
├── src/
│   └── README.md
└── docs/
    └── testing-checklist.md
```

## Setup
1. Install a supported Python version on your development computer or Raspberry Pi.
2. Create and activate a virtual environment.
3. Install only the dependencies required by your implementation:
   ```bash
   pip install -r requirements.txt
   ```
4. Add your source code under `src/`.
5. Keep passwords, API keys, email credentials, and personal face images out of GitHub.

## Privacy and security
- Obtain consent before enrolling anyone's face.
- Store biometric data securely and limit access to it.
- Never upload real face images, passwords, email app passwords, or private keys to a public repository.
- Test with the physical lock disconnected first.
- Provide a safe manual override and ensure a power or software failure cannot trap someone inside.

## Project details to complete
- Student name: Rutuja Kulkarni
- Degree/branch: B.Tech, Electronics & Telecommunication
- College: ____________________
- Project guide: ____________________
- Hardware used: ____________________
- Recognition method/library: ____________________
- Notification method: ____________________

## Disclaimer
This is an educational project starter. It is not a certified security system and must not be used to secure real premises without professional design, review, and testing.
